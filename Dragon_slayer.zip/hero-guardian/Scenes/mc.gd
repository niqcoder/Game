extends CharacterBody2D

@onready var anima = $AnimatedSprite2D
var SPEED = 100.0
const JUMP_VELOCITY = -250.0
var DTR = false
var DTL = false
var running  = false

	
	

func _physics_process(delta: float) -> void:
	
	if Input.is_action_just_released("ui_right"):
				if running == true:
					running  = false
				DTR = true
				$Timer.start()
	if Input.is_action_just_released("ui_left"):
				if running == true:
					running  = false 
				DTL = true
				$Timer.start()
	
	
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle jump.
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_axis("ui_left", "ui_right")
	if Input.is_action_just_pressed("ui_right"):
		if DTR == true:
			running = true
	if Input.is_action_just_pressed("ui_left"):
		if DTL == true:
			running  = true
		
	
	if is_on_floor():
		if direction == 0:
			anima.play("Idle")
		elif direction > 0:
			if running == false:
								anima.play("Walk")
			elif running == true:
																anima.play("Run")
			
			
			anima.flip_h = false
		elif direction < 0:
			if running == false:
				anima.play("Walk")
			elif running == true:
				anima.play("Run")
			
			
		
			anima.flip_h = true
	else:
		if velocity.y < 0:
			anima.play("Jump")
		else:
			anima.play("Dead")
	
	if running == true:
		SPEED = 250
	
		
	else:
		SPEED = 100
	
	if direction:
	
		velocity.x = direction * SPEED 
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()
	

	
	


func _on_timer_timeout() -> void:
	DTR = false
	DTL = false 
	
	
	
	
