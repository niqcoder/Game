extends Area2D


# Haha
@onready var time = $Timer


func _on_body_entered(body: Node2D) -> void:
	
	print("You Died!!")
	Engine.time_scale = 0.5
	body.get_node("CollisionShape2D").queue_free()
	time.start()
	

	


func _on_timer_timeout() -> void:
	Engine.time_scale = 1.0
	#Ads.show_interstitial()
	get_tree().reload_current_scene()
