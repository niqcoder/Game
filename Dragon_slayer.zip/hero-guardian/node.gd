extends Node

const POOL_SIZE = 4
var players = []
var next = 0

func _ready():
	for i in POOL_SIZE:
			var p = AudioStreamPlayer.new()
			add_child(p)
			players.append(p)
									
func play_sound(source: AudioStreamPlayer2D):
	players[next].stream = source.stream
	players[next].volume_db = source.volume_db
	players[next].play()
	next = (next + 1) % POOL_SIZE
