extends Area2D

var count = 0

func _on_body_entered(body):
	if body.is_in_group("player"):
		SFX.play_sound($CoinSound)
		queue_free()
		count = count  + 1
	print(count)
